class Block_list:
    def __init__(self , key ):
        self.username = key 

    def __str__(self):
            return f' username : {self.key}'
        