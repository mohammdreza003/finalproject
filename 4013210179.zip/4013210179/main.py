from logic import Logic
from interface import Interface
logic = Logic()
interface = Interface(logic)
interface.run()
 